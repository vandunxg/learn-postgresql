```text
1 |       2 |       3
3 |       1 |       3
(3 rows)
```

Hoặc nếu muốn loại bỏ tất cả row trùng lặp, chúng ta sẽ phải chạy câu lệnh sau:

```text
forumdb=> select distinct category, count(*) over (partition by
category),count(*) over ()
from posts
order by category;
 category | count | count
----------+-------+-------
        1 |       2 |       3
        3 |       1 |       3
(2 rows)
```

Trong query trước, window function đầu tiên aggregate dữ liệu bằng field `category`, còn window function thứ hai aggregate dữ liệu của toàn bộ table.

Với window function, có thể aggregate dữ liệu trong các field khác nhau trong cùng một query.

Như đã thấy ở đây, chúng ta có thể định nghĩa window frame trực tiếp ở query level, nhưng cũng có thể định nghĩa một alias cho window frame. Ví dụ, query trước trở thành:

```text
forumdb=> select distinct category, count(*) over w1 ,count(*) over W2
from posts
WINDOW w1 as (partition by category),W2 as ()
order by category;
 category | count | count
----------+-------+-------
        1 |       2 |       3
        3 |       1 |       3
(2 rows)
```

Việc sử dụng alias được gọi là `WINDOW` clause. `WINDOW` clause rất hữu ích khi chúng ta có nhiều aggregate.

## Giới thiệu một số function hữu ích

Window function có thể sử dụng tất cả aggregate function mà chúng ta đã tìm hiểu trong chapter trước. Ngoài ra, window function còn giới thiệu các aggregate function mới.

Trước khi xem xét một số function đó, hãy giới thiệu một function đặc biệt là `generate_series`. `generate_series` chỉ đơn giản tạo ra một numerical series, ví dụ:

```text
forumdb=> select * from generate_series(1,5);
 generate_series
-----------------
                 1
                 2
                 3
                 4
                 5
(5 rows)
```

Trong các ví dụ sau, chúng ta sẽ sử dụng function này cho nhiều use case khác nhau.

## Function `ROW_NUMBER`

Bây giờ hãy xem function `ROW_NUMBER()`. Function `ROW_NUMBER()` gán một số tăng dần cho mỗi row trong partition:

```text
forumdb=> select category, row_number() over w from posts WINDOW w as
(partition by category) order by category;
 category | row_number
----------+------------
        1 |            1
        1 |            2
        3 |            1
(3 rows)
```

Trong query trước, chúng ta đã sử dụng `PARTITION BY` clause để chia window thành các subset dựa trên các value trong column `category`. Như có thể thấy, chúng ta có hai category value: `1` và `3`. Điều đó có nghĩa là chúng ta có hai window, và bên trong mỗi window, function `ROW_NUMBER()` gán các number như đã định nghĩa trước đó.

## `ORDER BY` clause

`ORDER BY` clause sort các value bên trong window. Chúng ta cũng có thể sử dụng option `NULLS FIRST` hoặc `NULLS LAST` để đặt null value ở đầu hoặc cuối thứ tự sort. Ví dụ, chúng ta có thể thực hiện một window function query không có `ORDER BY` clause, như trong snippet sau, nhưng phải chú ý đến loại function đang sử dụng và mục tiêu của chúng ta.

Nếu sử dụng aggregate function không phụ thuộc vào sort order, chẳng hạn function `COUNT`, chúng ta có thể tránh sort dữ liệu; nếu không, nên sort dữ liệu bên trong partition để tránh nguy cơ nhận được các kết quả khác nhau mỗi lần query được chạy:

```text
forumdb=> select category,row_number() over w,title
from posts WINDOW w as (partition by category order by title) order by
category;
 category | row_number |                  title
----------+------------+------------------------------
        1 |            1 | Indexing Mysql
        1 |            2 | Indexing PostgreSQL
        3 |            1 | A view of      Data types in C++
(3 rows)
```

Như có thể thấy, bên trong partition, dữ liệu được sort theo field `title`.

## `FIRST_VALUE`

Function `FIRST_VALUE` trả về value đầu tiên trong partition, ví dụ:

```text
forumdb=> \x
Expanded display is on.


forumdb=> select category,row_number() over w,title,first_value(title)
over w
from posts WINDOW w as (partition by category order by category) order by
category;
-[ RECORD 1 ]-----------------------------
category      | 1
row_number    | 1
title         | Indexing PostgreSQL
first_value | Indexing PostgreSQL
-[ RECORD 2 ]-----------------------------
category      | 1
row_number    | 2
title         | Indexing Mysql
first_value | Indexing PostgreSQL
-[ RECORD 3 ]-----------------------------
category      | 3
title         | A view of     Data types in C++
first_value | A view of       Data types in C++
```

## `LAST_VALUE`

Function `LAST_VALUE` trả về value cuối cùng trong partition, ví dụ:

```text
forumdb=> select category,row_number() over w,title,last_value(title) over
w
from posts WINDOW w as (partition by category order by category) order by
category;
-[ RECORD 1 ]----------------------------
category     | 1
row_number | 1
title        | Indexing PostgreSQL
last_value | Indexing Mysql
-[ RECORD 2 ]----------------------------
category     | 1
row_number | 2
title        | Indexing Mysql
last_value | Indexing Mysql
-[ RECORD 3 ]----------------------------
category     | 3
row_number | 1
title        | A view of    Data types in C++
last_value | A view of      Data types in C++
```

Điều quan trọng là luôn sử dụng `ORDER BY` clause khi dùng function `first_value()` hoặc `last_value()` để tránh kết quả không chính xác, như đã đề cập trước đó.

## `RANK`

Function `RANK` xếp hạng row hiện tại trong partition và có khoảng cách giữa các hạng. Nếu không chỉ định clause `PARTITION BY`, function không biết cách liên hệ tuple hiện tại, nên function liên hệ với chính nó, như thấy ở đây:

```text
forumdb=> select pk,title,author,rank() over () from posts ;
 pk |               title                | author | rank
----+------------------------------+--------+------
  5 | Indexing PostgreSQL                |        1 |     1
  6 | Indexing Mysql                     |        1 |     1
  7 | A view of   Data types in C++ |           2 |     1
(3 rows)
```

Nếu thêm `ORDER BY` clause, function sẽ xếp hạng theo thứ tự được chỉ định. Ví dụ, author có id `1` bắt đầu từ record 1, còn author có id `2` bắt đầu từ record 3, như trong ví dụ sau:

```text
forumdb=> select pk,title,author,rank() over (order by author) from posts
;
 pk |             title                | author | rank
----+------------------------------+--------+------
  5 | Indexing PostgreSQL              |        1 |     1
  6 | Indexing Mysql                   |        1 |     1
  7 | A view of   Data types in C++ |           2 |     3
(3 rows)
```

Nếu thêm clause `PARTITION BY`, cơ chế hoạt động vẫn như vậy; điểm khác biệt duy nhất là việc xếp hạng được tính bên trong partition chứ không phải trên toàn bộ table như trong ví dụ trước:

```text
forumdb=> select pk,title,author,rank() over (partition by author order by
author) from posts ;

 pk |             title                | author | rank
----+------------------------------+--------+------
  5 | Indexing PostgreSQL              |        1 |     1
  6 | Indexing Mysql                   |        1 |     1
  7 | A view of   Data types in C++ |           2 |     1
(3 rows)
```

## `DENSE_RANK`

Function `DENSE_RANK` tương tự function `RANK`. Điểm khác biệt là function `DENSE_RANK` xếp hạng row hiện tại trong partition mà không có khoảng cách:

```text
forumdb=> select pk,title,author,dense_rank() over (order by author) from
posts order by category;
 pk |             title                | author | dense_rank
----+------------------------------+--------+------------
  5 | Indexing PostgreSQL              |        1 |             1
  6 | Indexing Mysql                   |        1 |             1
  7 | A view of       Data types in C++ |            2 |            2
(3 rows)
```

## Function `LAG` và `LEAD`

Trong section này, chúng ta sẽ trình bày cách function `LAG` và `LEAD` hoạt động. Trước hết, chúng ta sẽ thiết lập environment và tạo một sequence number như đã làm trước đó:

```text
forumdb=>      select x from generate_series(1,5) as x;
 x
---
 1
 2
 3
 4
 5
(5 rows)
```

Đây là điểm bắt đầu cho ví dụ này. Official documentation (https://www.postgresql.org/docs/current/functions-window.html) định nghĩa function `LAG` như sau:

> Function `LAG` trả về một value được đánh giá tại row nằm trước row hiện tại một khoảng bằng offset trong partition; nếu không có row như vậy, function thay vào đó trả về default (default phải có cùng type với value). Cả offset và default đều được đánh giá theo row hiện tại. Nếu bị bỏ qua, offset mặc định là `1` và default là null.

Bây giờ hãy viết statement sau:

```text
forumdb=> select x,lag(x) over w from (select generate_series(1,5) as x) V
WINDOW w as (order by x) ;
 x | lag
---+-----
 1 |
 2 |     1
 3 |     2
 4 |     3
 5 |     4
(5 rows)
```

Như có thể thấy, function `lag` trả về một result set với offset value bằng `1`. Nếu đưa vào một offset parameter, function `lag` sẽ trả về một result set với offset bằng số mà chúng ta truyền vào, như trong ví dụ tiếp theo:

```text
forumdb=> select x,lag(x,2) over w from (select generate_series(1,5) as x)
V WINDOW w as (order by x) ;
 x | lag
---+-----
 1 |
 2 |
 3 |     1
 4 |     2
 5 |     3
(5 rows)
```

Function `lead` là phần đối lập với function `lag`, như được mô tả trong official documentation:

> “Function `LEAD` trả về value được đánh giá tại row nằm sau row hiện tại một khoảng bằng offset trong partition; nếu không có row như vậy, function thay vào đó trả về default (default phải có cùng type với value đã nêu). Cả offset và default đều được đánh giá theo row hiện tại. Nếu bị bỏ qua, offset mặc định là `1` và default trở thành null.”

Dưới đây là một vài ví dụ cho thấy cách function này hoạt động. Trong ví dụ đầu tiên, chúng ta sẽ sử dụng function `lead` không có parameter:

```text
forumdb=# select x,lead(x) over w from (select generate_series(1,5) as x)
V WINDOW w as (order by x) ;
 x | lead
---+------
 1 | 2
 2 | 3
 3 | 4
 4 | 5
 5 |
(5 rows)
```

Như có thể thấy trong function `lead`, offset được tính từ các row bên dưới.

Bây giờ hãy xem một ví dụ sử dụng function `lead` với offset parameter:

```text
forumdb=> select x,lead(x,2) over w from (select generate_series(1,5) as
x) V WINDOW w as (order by x) ;
 x | lead
---+------
 1 |     3
 2 |     4
 3 |     5
 4 |
 5 |
(5 rows)
```

## Function `CUME_DIST`

Function `CUME_DIST` tính cumulative distribution của một value trong partition. Function này được mô tả trong official documentation như sau:

> “Function `CUME_DIST` tính fraction của các row trong partition có giá trị nhỏ hơn hoặc bằng giá trị của row hiện tại và các peer của nó.”

Hãy xem một ví dụ:

```text
forumdb=> select x,cume_dist() over w from (select generate_series(1,5) as
x) V WINDOW w as (order by x) ;
 x | cume_dist
---+-----------
 1 |         0.2
 2 |         0.4
 3 |         0.6
 4 |         0.8
 5 |           1
(5 rows)
```

Vì function được định nghĩa về mặt toán học, function `cume_dist` không bao giờ có value lớn hơn value hiện tại của field.

## Function `NTILE`

PostgreSQL `NTILE` function group các row được sort trong partition. Bắt đầu từ `1` cho đến parameter value được truyền vào function `NTILE`, mỗi group được gán một bucket number.

Parameter truyền vào function `NTILE` xác định chúng ta muốn bucket gồm bao nhiêu record.

Bây giờ hãy xem một ví dụ về cách nó hoạt động bằng cách thử chia result set thành hai bucket:

```text
forumdb=> select x,ntile(2) over w from (select generate_series(1,6) as x)
V WINDOW w as (order by x) ;
 x | ntile
---+-------
 1 |       1
 2 |       1
 3 |       1
 4 |       2
 5 |       2
 6 |       2
(6 rows)
```

Nếu muốn chia result set thành ba bucket, chúng ta sẽ chạy statement sau:

```text
forumdb=> select x,ntile(3) over w from (select generate_series(1,6) as x)
V WINDOW w as (order by x) ;
 x | ntile
---+-------
 1 |       1
 2 |       1
 3 |       2
 4 |       2
 5 |       3
 6 |       3
(6 rows)
```

Function `NTILE()` nhận một integer và cố chia window thành một số bucket cân bằng, chỉ rõ mỗi row thuộc về bucket nào.

Trong section này, chúng ta đã giới thiệu một số feature cho phép thực hiện data mining cơ bản. Ví dụ, có thể dùng `lag` và `lead` để so sánh các row khác nhau trong một table, từ đó so sánh salary của các employee khác nhau hoặc so sánh các collection từ những ngày khác nhau.

Trong section tiếp theo, chúng ta sẽ đi vào chi tiết hơn và tìm hiểu thêm một số feature nâng cao của window function.

## Sử dụng advanced statement window function

Trong section này, chúng ta sẽ thảo luận chi tiết về advanced window function và tìm hiểu một số technique có thể hữu ích để thực hiện data analysis chi tiết hơn.

Hãy bắt đầu bằng một query mà chúng ta đã thấy ở đầu chapter này:

```text
forumdb=> select distinct category, count(*) over (partition by category)
from posts order by category;
    category | count
    ----------+-------
           1 |     2
           3 |     1
(2 rows)
```

Dưới đây là một cách khác để viết cùng aggregate mà chúng ta đã mô tả trước đó:

```text
forumdb=> select distinct category, count(*) over w1
from posts WINDOW w1 as (partition by category RANGE BETWEEN UNBOUNDED
PRECEDING AND CURRENT ROW)
order by category;
    category | count
    ----------+-------
           1 |     2
           3 |     1
(2 rows)
```

`RANGE BETWEEN UNBOUNDED PRECEDING AND CURRENT ROW` có nghĩa là gì? Đây là các condition mặc định, được gọi là frame clause. Điều này có nghĩa là dữ liệu trước hết được partition theo `category`, sau đó bên trong partition, count được tính bằng cách reset count mỗi khi frame thay đổi.

## Frame clause

Trong section này, chúng ta sẽ nói về frame clause, cho phép quản lý partition theo một cách khác. Frame clause có hai dạng:

- `Rows between start_point and end_point`
- `Range between start_point and end_point`
